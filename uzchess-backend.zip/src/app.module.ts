import { Module } from '@nestjs/common';
import { LibraryModule } from './features/library/library.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { typeOrmConfig } from './core/configs/typeorm.config';
import { CommonModule } from './features/common/common.module';
import { JwtModule } from '@nestjs/jwt';
import { CqrsModule } from '@nestjs/cqrs';
import { AuthModule } from './features/auth/auth.module';
import { APP_GUARD } from '@nestjs/core';
import { AuthGuard } from './core/guards/auth.guard';
import { PermissionGuard } from './core/guards/permission.guard';
import { CacheModule } from '@nestjs/cache-manager';
import { NewsModule } from './features/news/news.module';
import { RoleGuard } from './core/guards/role.guard';
import { CoursesModule } from './features/courses/courses.module';

@Module({
  imports: [
    JwtModule.register({
      global: true,
      secret: 'ForTheLoveOfGodDontUseThisInProduction',
      signOptions: {
        expiresIn: '1h',
      },
    }),
    TypeOrmModule.forRoot(typeOrmConfig),
    CqrsModule.forRoot(),
    CacheModule.register({
      title:1000*60*30
    }),
    AuthModule,
    LibraryModule,
    CommonModule,
    NewsModule,
    CoursesModule
  ],
  providers: [
    {provide: APP_GUARD, useClass: AuthGuard},
    {provide: APP_GUARD, useClass: RoleGuard},
    {provide: APP_GUARD, useClass: PermissionGuard}

  ]
})
export class AppModule {}
import {CommandHandler, ICommandHandler} from "@nestjs/cqrs";
import {RegisterCommand} from "./register.command";
import {User} from "@/features/auth/entities/user.entity";
import {AlreadyExistsException} from "@core/exceptions/already-exists.exception";
import {Otp} from "@/features/auth/entities/otp.entity";

@CommandHandler(RegisterCommand)
export class RegisterHandler implements ICommandHandler<RegisterCommand> {
  async execute({payload}: RegisterCommand) {
    const user = await User.findOneBy({username: payload.username});
    if (user && user.isVerified && user.password)
      throw new AlreadyExistsException();

    if (user) {
      await User.remove(user);
    }

    let newUser = User.create(payload);
    newUser = await User.save(newUser);
    let otpCode = new Otp();
    otpCode.userId = newUser.id;

    let randInt = Math.ceil(Math.random() * 999999).toString();
    let code: string[] = []
    for (let i = randInt.length; i < 6; i++) {
      code.push('0');
    }
    code.push(randInt)

    otpCode.code = code.join('')

    await Otp.save(otpCode);

    console.log(otpCode.code);
    // TODO: email orqali jo'natish

    return newUser;
  }
}